package com.siteview.snmp.model;

public class Mib {

	public static final String OID_STRING = "1.3.6.1.2.1";
	
	
}
