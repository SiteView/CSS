package com.siteview.snmp.pojo;

/**
 * 附加topo数据条目
 * @author haiming.wang
 *
 */
public class Directitem {

	private String localPortInx;
	private String localPortDsc;
	private String peerId;
	private String peerIp;
	private String peerPortInx;
	private String peerPortDsc;
	public String getLocalPortInx() {
		return localPortInx;
	}
	public void setLocalPortInx(String localPortInx) {
		this.localPortInx = localPortInx;
	}
	public String getLocalPortDsc() {
		return localPortDsc;
	}
	public void setLocalPortDsc(String localPortDsc) {
		this.localPortDsc = localPortDsc;
	}
	public String getPeerId() {
		return peerId;
	}
	public void setPeerId(String peerId) {
		this.peerId = peerId;
	}
	public String getPeerIp() {
		return peerIp;
	}
	public void setPeerIp(String peerIp) {
		this.peerIp = peerIp;
	}
	public String getPeerPortInx() {
		return peerPortInx;
	}
	public void setPeerPortInx(String peerPortInx) {
		this.peerPortInx = peerPortInx;
	}
	public String getPeerPortDsc() {
		return peerPortDsc;
	}
	public void setPeerPortDsc(String peerPortDsc) {
		this.peerPortDsc = peerPortDsc;
	}
	
	
}
