package com.siteview.snmp.pojo;

public class Vrid {

	 private String vrId;
     private String masterIp;
     private String primaryIp;
     private String virtualMac;
	public String getVrId() {
		return vrId;
	}
	public void setVrId(String vrId) {
		this.vrId = vrId;
	}
	public String getMasterIp() {
		return masterIp;
	}
	public void setMasterIp(String masterIp) {
		this.masterIp = masterIp;
	}
	public String getPrimaryIp() {
		return primaryIp;
	}
	public void setPrimaryIp(String primaryIp) {
		this.primaryIp = primaryIp;
	}
	public String getVirtualMac() {
		return virtualMac;
	}
	public void setVirtualMac(String virtualMac) {
		this.virtualMac = virtualMac;
	}
     
}
